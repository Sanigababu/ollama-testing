gunicorn -k uvicorn.workers.UvicornWorker ollama_api:app --bind=0.0.0.0 --timeout 300
