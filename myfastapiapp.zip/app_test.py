import streamlit as st
import time

def generate_local_response(prompt):
    """Generate a local response based on user input"""
    normalized_prompt = prompt.lower().strip()
    
    # Casual conversation responses
    if normalized_prompt in ["hi", "hello", "namaste", "hey"]:
        return "Namaste! 🙏 I'm your Ayurvedic companion. How can I support your wellness journey today?"
    
    if normalized_prompt in ["thank you", "thanks"]:
        return "You're most welcome! 🌿 Remember, true health comes from balance - may you find yours today."
    
    if not normalized_prompt:
        return "Please share a wellness question so I can assist you. 🌼"
    
    # Simple placeholder for other wellness-related questions
    return (
        "That's a wonderful question! 🌿 In Ayurveda, each individual is unique, and balance is key. "
        "For personalized advice, it's best to consider your dosha (body type) and consult an Ayurvedic expert. "
        "Feel free to ask about remedies, herbs, yoga, or meditation too!"
    )

def main():
    st.set_page_config(
        page_title="🌿 Ayurvedic Companion",
        page_icon="🌿",
        layout="centered"
    )
    
    st.title("🌿 Ayurvedic Companion")
    st.caption("A friendly guide to natural wellness")
    
    # Initialize chat history
    if "messages" not in st.session_state:
        st.session_state.messages = [{
            "role": "assistant", 
            "content": "Namaste! 🙏 I'm your Ayurvedic companion. How can I support your wellness journey today?"
        }]
    
    # Display chat messages
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
    
    # Accept user input
    if prompt := st.chat_input("Ask about wellness..."):
        # Add user message to chat history
        st.session_state.messages.append({"role": "user", "content": prompt})
        
        # Display user message
        with st.chat_message("user"):
            st.markdown(prompt)
        
        # Display assistant response
        with st.chat_message("assistant"):
            with st.spinner("Thinking... 🌿"):
                time.sleep(1)  # simulate a natural delay
                response = generate_local_response(prompt)
                st.markdown(response)
        
        # Add assistant response to chat history
        st.session_state.messages.append({"role": "assistant", "content": response})

if __name__ == "__main__":
    main()
